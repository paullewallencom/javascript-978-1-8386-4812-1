import React from 'react'
import './styles/_App.scss'
import Main from './components/Main/Main';

function App() {

  return (
    <div className="App">
      <Main />
    </div>
  )
}

export default App

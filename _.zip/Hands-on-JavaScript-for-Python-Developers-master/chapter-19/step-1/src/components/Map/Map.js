import React from 'react'

function Map() {
  return (
    <>
      <h1>Map</h1>
    </>
  )
}
export default Map